# ==========================================
# PYTHON LIBRARIES
# ==========================================
import csv
from rich.console import Console 
from rich.table import Table






# ================================================
# 1. CONSTANTS (Checks if this or that is allowed)
# ================================================







# ===================================================
# 2. DATA VALIDATION FUNCTIONS (based on my use case)
# ===================================================
 #store user_input into variables 
def Data_Validation():

    Food_Name = input("Food_Name : ")
    Expiry_Date = input("Expiry Date : ")
    Date_Purchased = input("Date Purchased : ")
    Inventory_Quantity = input("Inventory Quantity : ")

    #storing user input data in a dictionary
    User_Input = {
            "Food_Name": Food_Name,
            "Expiry_Date": Expiry_Date,
            "Date_Purchased": Date_Purchased,
            "Inventory_Quantity": Inventory_Quantity,
    }

    # Direct python to the file location (done locally)
    file_location = r"C:\Users\thesm\Downloads\food_inventory_dataset.csv"

     # CSV file containing the dataset
    with open(file_location, "r", encoding="utf-8-sig") as csv_dataset:


        # Tell Python to use the CSV column headers, basically access all the columns in the csv
        reader = csv.DictReader(csv_dataset)

        # Food Name Validation
        if Food_Name == "":
            print("Please enter something")

        else:

            #loop through the rows in csv 
            for row in reader:

                #tell python which column to use
                csv_food_name = row["Food_Name"]
                csv_category = row["Category"]

                # Check if CSV food name is inside user's input(Food_Name) , using .lower() method accept Uppercase and Lowercase letters
                if Food_Name.lower() in csv_food_name.lower():

                # Automatically assign food_name to category
                    User_Input["Category"] = csv_category

                    print("Food found!")
                    print(f"Food Name : {Food_Name}")
                    print(f"Category  : {csv_category}")

                    break
            


   


       

        
    
    
    #Category Validation
    
    
    #Expiry_Date Validation
    
    
    #Date_Purchased Validation
    
    
    #Inverntory_Quantity Validation
      

    return(User_Input)

print(Data_Validation())



# ===================================================
# 3. CLI / INPUT PROMPTS (Handles Retry Loops)
# ===================================================









# ==========================================
# 4. DATA COLLECTION & DISPLAY
# ==========================================












# ==========================================
# 5. MAIN APPLICATION LOOP
# ==========================================